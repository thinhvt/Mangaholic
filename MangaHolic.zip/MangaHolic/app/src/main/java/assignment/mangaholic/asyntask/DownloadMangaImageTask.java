package assignment.mangaholic.asyntask;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import assignment.mangaholic.listview.ImageList;
import assignment.mangaholic.util.AsyncHelper;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class DownloadMangaImageTask extends AsyncTask<String, Void, Bitmap> {
    private ImageList imageList;

    public DownloadMangaImageTask(ImageList imageList) {
        this.imageList = imageList;
    }

    @Override
    protected Bitmap doInBackground(String... strings) {
        return AsyncHelper.downloadImage(strings[0]);
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        imageList.addItem(bitmap);
    }
}
